package Actividad13;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.InputMismatchException;
import java.util.Scanner;

public class AC14Eje3 {
    public static void main(String[] args) throws IOException {
        try {
            Scanner sc = new Scanner(System.in);

            File fichero = new File(".\\src\\Actividad13\\AleatorioEmple.dat");
            //declara el fichero de acceso aleatorio
            RandomAccessFile file = new RandomAccessFile(fichero, "rw");

            //datos
            int dep; //departamentos

            System.out.println("Introduce un Identificador:");
            int id = sc.nextInt();

            long posicion = (id - 1) * 36; //(4+20+4+8) la posicion


            if (posicion >= file.length()) {
                System.out.println("El empleado con ID: " + id + ", NO EXISTE...");
            } else {
                System.out.println("Introduce una Subida de sueldo:");
                Double salario = sc.nextDouble();//salario

                file.seek(posicion); // nos posicionamos
                id = file.readInt(); // obtengo id de empleado
                char apellido[] = new char[10], aux;
                for (int i = 0; i < apellido.length; i++) {
                    aux = file.readChar();//recorro uno a uno los caracteres del apellido
                    apellido[i] = aux; //los voy guardando en el array
                }
                String apellidoS = new String(apellido);//convierto a String el array
                dep = file.readInt();//obtengo dep
                Double salarioOld = file.readDouble(); //obtengo salario
                Double sumaSal = (salarioOld + salario);

                //Modifico el Salario
                posicion = posicion + 4 + 20 + 4; //sumo el tamaño de ID+Apellido+Departamento
                file.seek(posicion); //Y nos posicionamos
                file.writeDouble(sumaSal);//Modifico el salario

                //Mostramos los datos requeridos
                System.out.println("Apellidos: " + apellidoS + " Salario Antiguo: " + salarioOld + " Salario Nuevo: " + sumaSal);
            }
            file.close(); //cerrar fichero
        }
        catch (FileNotFoundException fn ){
            System.err.println("\nNo se encuentra el fichero");
        }
        catch (IOException io) {
            System.err.println("\nError de E/S ");
        }
        catch (ArrayIndexOutOfBoundsException no) {
            System.err.println("\nNo tiene argumento");
        }
        catch (InputMismatchException e){
            System.err.println("\nTiene que escribir solo numeros");
        }
    }
}
/**    StringBuffer buffer = null;//buffer para almacenar apellido

                file.seek(posicion); //nos posicionamos
                        file.writeInt(id); //uso i+1 para identificar empleado
                        buffer = new StringBuffer(apellido[i]);
                        buffer.setLength(10); //10 caracteres para el apellido
                        file.writeChars(buffer.toString());//insertar apellido
                        file.writeInt(dep[i]); //insertar departamento
                        file.writeDouble(salario[i]);//insertar salario

 **/